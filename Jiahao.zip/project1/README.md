# Particle system

Theme: need a bit of help to get going

It starts with a 'hair ball in the center', all the particles are unorgnized 
Once mouse is pressed, they will shoot out from the center and bouce on the walls.
Some of them will jitters and accelerate suddenly into random direction
Using mouse to collect all the particles to see what kind of pattern they can create
