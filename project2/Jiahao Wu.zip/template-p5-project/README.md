# Data visualization
This project displays all flight route either national or international for US(There are 2 colors represent each category)
Every yellow dot symbolizes an airport location. Whenever an airplane is about to take off, the dot will blink for few seconds and then disapear
All particles are assigned to a random timer between 1 to 100, they will only take off when it reaches 100. Once it arrives at its destination, timer gets reset and it will return to where it came
For the backgroud image, I used an api to get the static world map from openbox.


![1](https://user-images.githubusercontent.com/25802927/223583522-b0f82633-721c-466a-b495-2741099097f4.png)
